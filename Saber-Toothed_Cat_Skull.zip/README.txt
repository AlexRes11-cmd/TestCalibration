                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:472463
Saber-Toothed Cat Skull by Curriculum is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

 Just one look at the impressive skull of this massive feline and you’ll be glad it’s been   
extinct for 11,000 years. Walking the Earth alongside our human ancestors for millennia, saber-toothed cats’ impressive fangs were precision killing tools that helped earn them the scientific name Smilodon fatalis.      
   
_______  
With the intent of making the 3D printing ecosystem more accessible to educators,   
MakerBot Academy has selected Common Core Standards for English Language Arts and Mathematics that align with our 3D printed content. Our goal is to lower the barrier to 3D printing in the classroom by directing teachers to standards-aligned resources. We hope to make the process of incorporating 3D printing technology into the curricula more   
seamless for teachers and students alike. Find these resources in the "Instructions" tab.     


# Instructions

STORIED SKULLS  
==  
Resources & Common Core Standards Alignments  
____  
1st Grade:  
---  
**Lesson Suggestion:** [Community Resources for Science][Community Resources for Science], [Discovery Science Center][Discovery Science Center]     
   
   **Common Core Standard Alignments:**     
   
   Reading: Informational Text  (Craft and Structure)  
>CCSS.ELA-Literacy.RI.1.4  
Ask and answer questions to help determine or clarify the meaning of words and phrases in a text.  
>CCSS.ELA-Literacy.RI.1.6  
Distinguish between information provided by pictures or other illustrations and information provided by the words in a text.  
>CCSS.ELA-Literacy.W.1.7  
Participate in shared research and writing projects (e.g., explore a number of "how-to" books on a given topic and use them to write a sequence of instructions).  
>CCSS.ELA-Literacy.W.1.8  
With guidance and support from adults, recall information from experiences or gather information from provided sources to   
answer a question.     
   
   4th Grade:  
---     
   
   **Lesson Suggestion:** [National Park Service][National Park Service], [Science & Health Education Partnership][Science & Health Education Partnership]     
   
   **Common Core Standard Alignments:**     
   
   Writing  (Text Types and Purposes)  
>CCSS.ELA-Literacy.W.4.1  
Write opinion pieces on topics or texts, supporting a point of view with reasons and information.  
>CCSS.ELA-Literacy.W.4.2  
Write informative/explanatory texts to examine a topic and convey ideas and information clearly.  
>CCSS.ELA-Literacy.W.4.3  
Write narratives to develop real or imagined experiences or events using effective technique, descriptive details, and clear event sequences.     
   
   6th Grade:  
---     
   
   **Lesson Suggestion:** [New York State Department of Environmental Conservation][New York State Department of Environmental Conservation], [American Association for the Advancement of Science][American Association for the Advancement of Science]  
**Common Core Standard Alignments:**     
   
   Writing (Text Types and Purposes)  
>CCSS.ELA-Literacy.W.6.1  
Write arguments to support claims with clear reasons and relevant evidence.  
>CCSS.ELA-Literacy.W.6.2  
Write informative/explanatory texts to examine a topic and convey ideas, concepts, and information through the selection,   
organization, and analysis of relevant content.  
>CCSS.ELA-Literacy.W.6.3  
Write narratives to develop real or imagined experiences or events using effective technique, relevant descriptive details, and well-structured event sequences.     
   
   Science & Technology (Integration of Knowledge and Ideas)  
>CCSS.ELA-Literacy.RST.6-8.7  
Integrate quantitative or technical information expressed in words in a text with a version of that information expressed visually (e.g., in a flowchart, diagram, model, graph, or table).  
>CCSS.ELA-Literacy.RST.6-8.8  
Distinguish among facts, reasoned judgment based on research findings, and speculation in a text.  
>CCSS.ELA-Literacy.RST.6-8.9  
Compare and contrast the information gained from experiments, simulations, video, or multimedia sources with that gained from reading a text on the same topic.     
   
   High School:  
---     
   
   **Lesson Suggestion:** [Arizona State][Arizona State]     
   
   **Common Core Standard Alignments:**     
   
   Writing  (Text Types and Purposes)  
>CCSS.ELA-Literacy.W.11-12.1  
Write arguments to support claims in an analysis of substantive topics or texts, using valid reasoning and relevant and sufficient evidence.  
>CCSS.ELA-Literacy.W.11-12.2  
Write informative/explanatory texts to examine and convey complex ideas, concepts, and information clearly and accurately through the effective selection, organization, and analysis of content.  
>CCSS.ELA-Literacy.W.9-10.3  
Write narratives to develop real or imagined experiences or events using effective technique, well-chosen details, and well-structured event sequences.     
   
   Science & Technology (Integration of Knowledge and Ideas)  
>CCSS.ELA-Literacy.RST.11-12.7  
Integrate and evaluate multiple sources of information presented in diverse formats and media (e.g., quantitative data, video, multimedia) in order to address a question or solve a problem.  
>CCSS.ELA-Literacy.RST.11-12.8  
Evaluate the hypotheses, data, analysis, and conclusions in a science or technical text, verifying the data when possible and corroborating or challenging conclusions with other sources of information.  
>CCSS.ELA-Literacy.RST.11-12.9  
Synthesize information from a range of sources (e.g., texts, experiments, simulations) into a coherent understanding of a process, phenomenon, or concept, resolving conflicting information when possible.  
[Community Resources for Science]: http://www.crscience.org/lessonplans/1_youarewhatyoueat_atterholt_09-10.pdf  
[Discovery Science Center]: http://www.discoverycube.org.php5-20.dfw1-1.websitetestlink.com/wp-content/uploads/2011/06/1st_Plant-Eaters-vs-Meat-Eaters.pdf  
[National Park Service]: http://www.nps.gov/seki/forteachers/upload/how-to-read-a-skull-like-an-open-book.pdf  
[Science & Health Education Partnership]: http://www.seplessons.org/node/366  
[New York State Department of Environmental Conservation]: http://www.dec.ny.gov/docs/administration_pdf/lpskullscience.pdf  
[American Association for the Advancement of Science]: http://sciencenetlinks.com/lessons/skull-diversity/  
[Arizona State]: http://extension.arizona.edu/sites/extension.arizona.edu/files/pubs/az1145.pdf   


# Custom Section

![Alt text](https://cdn.thingiverse.com/assets/1c/0e/0e/b4/31/Storied_Skulls_3.png)

Part of the [Storied Skulls](http://www.thingiverse.com/MakerBot/collections/storied-skulls) collection